---
name: static-remix
description: Turn a PDF of winning competitor static ads into on-brand recreations for your product using Gemini 3 Pro image generation. Run with /static-remix [optional path to PDF].
---

# static-remix

Turn a PDF of winning competitor static ads into on-brand recreations for your product using Gemini 3 Pro image generation (Nano Banana Pro).

---

## Prerequisites — verify before every run

Run these checks; if any fail, stop and tell the user what to install/set:

```bash
python3 -c "import fitz; print('PyMuPDF OK')" 2>&1 || echo "MISSING: pip install pymupdf"
perl -e "use MIME::Base64; print 'perl OK\n'" 2>&1 || echo "MISSING: perl MIME::Base64"
curl --version | head -1
[[ -n "${GEMINI_API_KEY:-}" ]] && echo "API key set" || echo "MISSING: export GEMINI_API_KEY=..."
```

Script paths (absolute, always use these):
- GEMINI_SCRIPT: `~/.claude/skills/static-remix/scripts/gemini-image-ref.sh`
- EXTRACT_SCRIPT: `~/.claude/skills/static-remix/scripts/extract-pdf-images.py`

---

## Step 1 — Locate PDF and create run folder

If the user passed a path as `/static-remix <path>`, use `$ARGUMENTS` as the PDF path.
Otherwise, use **AskUserQuestion** to ask:

> "Where is your PDF of competitor ads? (full path, e.g. ~/Downloads/winning-statics.pdf)"

Expand `~` to the actual home directory. Verify the file exists with `ls -lh "<pdf_path>"`.

Create the dated run folder and capture its path:

```bash
RUN_DIR="${HOME}/.claude/skills/static-remix/runs/$(date +%Y%m%d-%H%M)"
mkdir -p "${RUN_DIR}/source-images" "${RUN_DIR}/production"
echo "Run folder: ${RUN_DIR}"
```

Store `RUN_DIR` — you will use it throughout every subsequent step.

---

## Step 2 — Extract images from PDF

Run the extraction script:

```bash
python3 "${HOME}/.claude/skills/static-remix/scripts/extract-pdf-images.py" \
    "<pdf_path>" \
    "${RUN_DIR}/source-images" \
    | tee "${RUN_DIR}/extraction.json"
```

Parse `extraction.json`. Report to the user:
- Number of images extracted
- Detected heading font name and size
- List of detected framework names (the `"frameworks"` array)

Example output format to show the user:
```
Extracted 34 images from 12 pages.
Heading font detected: Helvetica-Bold 18pt
Frameworks found: US VS THEM · BOLD CLAIM · BEFORE & AFTER · TESTIMONIAL · PROBLEM/SOLUTION
```

---

## Step 3 — Ask the four REQUIRED questions

**NEVER skip these. NEVER silently default any answer. Ask all four before continuing.**

Use **AskUserQuestion** with a single multi-part message:

```
I found these ad frameworks in your PDF:
  [list each framework with image count, e.g. "US VS THEM (8 images)"]

Please answer all four questions:

a) Product URL (required — no default):

b) Total images you want produced (e.g. 10, 50, 100):

c) Variations per concept (usually 2 — same framework, one axis changes per
   variation such as camera angle or overlay wording):

d) How many images from each framework?
   You can say "even split across all frameworks" or give exact counts, e.g.:
   "20 US VS THEM, 10 BOLD CLAIM, 10 Before & After, 10 TESTIMONIAL"
   The counts × variations per concept must sum to your total from (b).
```

After the user replies, validate the math:

```
concepts_needed = total_images / variations_per_concept
sum_of_framework_counts = sum of all per-framework image counts given
```

- If `sum_of_framework_counts != total_images`: show the mismatch clearly and use **AskUserQuestion** to ask the user to fix it before continuing. Do not proceed until the numbers add up.
- If `total_images % variations_per_concept != 0`: flag the non-integer concept count and ask for a correction.

Once the math checks out, compute:
```
concepts = total_images / variations_per_concept
estimated_cost_usd = total_images * 0.25
```

If `estimated_cost_usd > 10`, show the estimate and use **AskUserQuestion** to confirm:
> "Estimated cost: $X.XX for N images at $0.25 each. Proceed? (yes/no)"

Stop if the user says no.

---

## Step 4 — Fetch product page and download product photo

Fetch the product URL the user provided. Use **WebFetch** on the URL.

**For Shopify stores**, also fetch `<base_url>.json` to get the structured product data including image URLs. Example: if URL is `https://example.myshopify.com/products/nano-banana-pro`, fetch `https://example.myshopify.com/products/nano-banana-pro.json`.

Identify the primary product image URL from either the page HTML or the `.json` response.

Download the product photo:

```bash
curl -L -o "${RUN_DIR}/product-photo.jpg" "<product_image_url>"
```

**CRITICAL: Use the Read tool to open `${RUN_DIR}/product-photo.jpg` and visually examine it.**

Write a concrete visual description of the package and save it:

```bash
cat > "${RUN_DIR}/product-visual.txt" << 'EOF'
[Your visual description here — be specific:]
- Bottle/package shape and color
- Cap/lid color and material
- Label: typography style, dominant colors, any illustrated elements
- Capsule/softgel/tablet color (if visible)
- Brand color palette (note all hex-approximate colors visible)
- Any icons, badges, or graphic elements on label
- Background/lifestyle context if shown
EOF
```

Also extract from the page:
- Product name (exact)
- Price (exact, e.g. "$39.99" or "$29.99 / $0.50 per serving")
- Key claims / benefits listed
- Any offer copy (subscribe & save %, bundle deals, free shipping threshold)

Save to `${RUN_DIR}/product-copy.txt`. **Never invent prices or offer copy — only use what you read from the page.**

---

## Step 5 — Teardown source examples

For each framework the user has allocated images to, pick the 1-2 best source examples from the extracted images. Use the **Read tool** to visually examine each image file at `${RUN_DIR}/source-images/<filename>`.

For each example, write a short teardown:

```
Framework: <NAME>
File: <filename>
Psychological hook: <why this works — fear, social proof, contrast, curiosity, etc.>
Keep: <visual element or structural pattern to preserve>
Swap: <what to replace with your brand — product, colors, copy, face, logo>
```

Save all teardowns to `${RUN_DIR}/teardowns.txt`.

---

## Step 6 — Write production briefs

Write one brief per concept. Concepts = `total_images / variations_per_concept`.
Distribute concepts across frameworks per the user's allocation.

Number concepts sequentially: concept_01, concept_02, …, concept_NN.

Each brief must include:

```
CONCEPT: concept_NN
FRAMEWORK: <framework name>
SOURCE EXAMPLE: <filename of the source image this concept is modeled on>

SCENE DESCRIPTION:
<2-4 sentences. Describe the visual scene in concrete detail: setting, lighting,
product placement, model/talent if any, props, camera angle.>

TEXT OVERLAYS (exact quoted copy):
  Headline: "<exact text>"
  Subhead: "<exact text or NONE>"
  Body:     "<exact text or NONE>"
  CTA:      "<exact text>"

VARIATION AXIS: <one thing that changes between var_01 and var_02>
  var_01: <describe the first version>
  var_02: <describe the second version>

NOTES: <anything important for generation — color palette hex codes, font mood, etc.>
```

**Copy rules:**
- Pull pricing and offer copy verbatim from `${RUN_DIR}/product-copy.txt`
- Never invent numbers, percentages, or claims not present on the product page

Save all briefs to `${RUN_DIR}/briefs.txt`.

---

## Step 7 — Generate images

Set the script path and make it executable:

```bash
GEMINI_SCRIPT="${HOME}/.claude/skills/static-remix/scripts/gemini-image-ref.sh"
chmod +x "${GEMINI_SCRIPT}"
PRODUCT_PHOTO="${RUN_DIR}/product-photo.jpg"
```

For each concept × variation, construct the full generation prompt from the brief:

```
[SCENE DESCRIPTION]

Text to display on the image:
- Headline: "[headline copy]"
- [Subhead line if present]
- CTA: "[CTA copy]"

VARIATION: [var_01 or var_02 description]

Visual style reference: match the brand palette and package shown in the reference image exactly.
Use [FRAMEWORK NAME] ad framework. Make it feel like a high-converting Facebook/Instagram static ad.
```

Run the script for each image. **Pass the product photo as the reference image on EVERY call.** Run sequentially (not in parallel):

```bash
"${GEMINI_SCRIPT}" \
    "<full_prompt>" \
    "4:5" \
    "${RUN_DIR}/production/concept_NN_var_MM.png" \
    "${PRODUCT_PHOTO}"
```

Use aspect ratio `4:5` by default (optimal for Meta feed). Use `9:16` if the brief explicitly calls for Stories/Reels format.

**Error handling:**
- HTTP 500 responses: note the failed path and retry at the end (after all other images complete)
- HTTP 4xx responses: log the error, skip that image, continue
- After all images are attempted, retry any HTTP-500 failures once more in sequence

Track a running count: log each success as `✓ concept_NN_var_MM.png saved`.

---

## Step 8 — Write report

After all images are generated, write `${RUN_DIR}/report.txt`:

```
STATIC-REMIX RUN REPORT
=======================
Date:        <YYYYMMDD-HHMM>
PDF source:  <pdf_path>
Product:     <product name>
Run folder:  <RUN_DIR>

IMAGES PRODUCED: N / N requested
[list any failed images]

TOP 3 CONCEPTS TO TEST FIRST
-----------------------------
1. concept_NN — <one-line reason: strongest psychological hook, clearest visual contrast, etc.>
2. concept_NN — <one-line reason>
3. concept_NN — <one-line reason>

TESTING PLAYBOOK
----------------
Budget per creative: $5–$10/day for 3 days (minimum viable signal)
Kill criteria:       CTR < 0.8% after $15 spend, or CPC > 3× account average
Graduate criteria:   CTR ≥ 1.5% and ROAS ≥ 1.5× — move to full budget

CONCEPT DETAILS
---------------
[For each concept:]
concept_NN [FRAMEWORK]
  Headline:   "..."
  Caption:    "..."
  var_01:     <one line>
  var_02:     <one line>
  Files:      concept_NN_var_01.png, concept_NN_var_02.png
```

---

## Step 9 — Final summary (chat message)

End with a concise chat message to the user. Do NOT dump the full report. Include only:

1. Run folder path
2. Number of images successfully generated
3. Top 3 concepts to test, each with a one-line reason

Example format:
```
Run complete → ~/.claude/skills/static-remix/runs/20250430-1423/

Generated 20 / 20 images.

Top 3 to test first:
• concept_03 (US VS THEM) — sharpest product contrast, proven competitor hook
• concept_07 (BOLD CLAIM) — strongest headline with price anchor
• concept_12 (TESTIMONIAL) — social proof variant most likely to earn trust with cold traffic

Full details in report.txt in the run folder.
```
